package ar.org.centro8.curso.java.TpObjetos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpObjetosApplicationTests {

	@Test
	void contextLoads() {
	}

}
